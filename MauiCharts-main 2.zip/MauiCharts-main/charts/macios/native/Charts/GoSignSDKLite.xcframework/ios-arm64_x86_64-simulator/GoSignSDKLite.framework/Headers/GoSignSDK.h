//
//  GoSignSDK.h
//  GoSignSDK
//
//  Created by Huy Nguyen on 05/09/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for GoSignSDK.
FOUNDATION_EXPORT double GoSignSDKVersionNumber;

//! Project version string for GoSignSDK.
FOUNDATION_EXPORT const unsigned char GoSignSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GoSignSDK/PublicHeader.h>


